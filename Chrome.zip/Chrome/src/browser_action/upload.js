/* This file handles JS specific to the upload page */

$("#cancel").on("click", function(){
	window.close();
});