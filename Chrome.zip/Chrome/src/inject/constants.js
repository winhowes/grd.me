var startTag = '~~grdme~~',
endTag = '~~!grdme~~',
NONCE_CHAR = "!",
UNABLE_TO_DECRYPT = "[Unable to decrypt message]",
UNABLE_startTag = "[start tag]",
UNABLE_endTag = "[end tag]",
frameOrigin = "https://decrypt.grd.me",
DECRYPTED_MARK,
FRAME_SECRET;